********************************************************************************
Copyright Since 2005 ColdBox Framework by Luis Majano and Ortus Solutions, Corp
www.coldbox.org | www.luismajano.com | www.ortussolutions.com
********************************************************************************
HONOR GOES TO GOD ABOVE ALL
********************************************************************************
Because of His grace, this project exists. If you don't like this, then don't read it, its not for you.

"Therefore being justified by faith, we have peace with God through our Lord Jesus Christ:
By whom also we have access by faith into this grace wherein we stand, and rejoice in hope of the glory of God.
And not only so, but we glory in tribulations also: knowing that tribulation worketh patience;
And patience, experience; and experience, hope:
And hope maketh not ashamed; because the love of God is shed abroad in our hearts by the 
Holy Ghost which is given unto us. ." Romans 5:5

********************************************************************************
WELCOME TO COLDBOX RELAX
********************************************************************************
Welcome To The ColdBox Relax: RESTFul Tools For Lazy Experts!
Created & copyright by Luis Majano (Ortus Solutions, Corp)

********************************************************************************
COLDBOX RELAX LICENSE
********************************************************************************
ColdBox is open source and bound to the Apache License, Version 2.0.

********************************************************************************
OPEN SOURCE INITIATIVE APPROVED
********************************************************************************
This software is Open Source Initiative approved Open Source Software.
Open Source Initiative Approved is a trademark of the Open Source Initiative.

********************************************************************************
COLDBOX RELAX IMPORTANT LINKS
********************************************************************************
Source
- http://github.com/coldbox/coldbox-relax
- https://github.com/coldbox/coldbox-relax/issues
Documentation
- http://wiki.coldbox.org/wiki/Projects:Relax.cfm
Blog
- http://blog.coldbox.org/archives.cfm/category/codedepot

********************************************************************************
COLDBOX RELAX INSTALLATION
********************************************************************************
http://wiki.coldbox.org/wiki/Projects:Relax.cfm

Drop in your modules convention folder as 'relax', fire it up.

********************************************************************************
SYSTEM REQUIREMENTS
********************************************************************************
- Railo 3.1 and above
- ColdFusion MX 8.X and above
- Session scope enabled.

********************************************************************************
CHANGELOG
********************************************************************************
== Version 1.3 ==
#7 MSSQL adapter bug when reading mssql db
#8 Ability to define API global parameters now and also document them

== Version 1.2 ==
#3 Critical fix for MSSQl users on wrong interface type
#4 Updated logos and images and promos
#5 Check for updates feature

== Version 1.1 ==
#1 Fixes to logs when reports give 0 records
#2 Updates to resource id calculations so autoreloading does not corrupt them.

== Version 1.0 ==

* Initial Release of Relax.

----

AS ALWAYS, VISIT THE WIKI FOR THE LATEST DOCUMENTATION
 
== THE DAILY BREAD ==

 "I am the way, and the truth, and the life; no one comes to the Father, but by me (JESUS)" Jn 14:1-12